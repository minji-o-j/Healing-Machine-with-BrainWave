﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;


namespace compare4
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        [DllImport("user32.dll")]
        static extern uint keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

        public static int second1 = 30;
        public static ArrayList FTData = new ArrayList();
        public static double OneSecFFT;
        public static double ct = 0.03493;

        public static int count = 0;  //받아오는 파일

        public static int second2 = 10;
        public static ArrayList FTData2 = new ArrayList();
        public static double OneSecFFT2 = 0.0;
        public static double avr1 = 0.0;
        public static ArrayList userdata = new ArrayList();

        public static int second3 = 30;
        public static ArrayList FTData3 = new ArrayList();
        public static double OneSecFFT3 = 0.0;


        //   public static MediaPlayer music = new MediaPlayer();   //음악재생
        //   public static System.Windows.Forms.Label label = new System.Windows.Forms.Label();

        public MainWindow()
        {
            InitializeComponent();
        }


        /* public static void Main(string[] args)
         {
             TicTok1();
             TicTok2();
             TicTok3();
         }*/

        //가장높은 값 구하기
        /*    public static double Max(ArrayList ftdata)
             {

                 return ct;
             }*/

        //평균구하기
        public static double arr_avr(ArrayList myarr)
        {
            double total = 0;
            int count = myarr.Count;
            for (int i = 0; i < count; i++)
            {
                total += (double)myarr[i];
            }
            return total / count;
        }

        //처음 10초
        private static System.Windows.Forms.Timer timer_c;
        public static void TicTok2()
        {
            timer_c = new System.Windows.Forms.Timer() { Interval = second2 * 1000 };
            timer_c.Tick += new EventHandler(choice);
            timer_c.Enabled = true;
        }

        //10초 영상 or 노래
        public static void choice(object sender, System.EventArgs e)
        {
            FTData2 = new ArrayList();

            while (FTData.Count < second2)
            {
                // int imsy = int.Parse(DateTime.Now.ToString("HH-mm-ss dd"));
                string path = @"C:\Users\김나혜\Desktop\bread data\" + count + ".txt";
                count++;

                FileInfo fi = new FileInfo(path);
                string RData = "0.1";
                if (fi.Exists == true)
                {
                    RData = System.IO.File.ReadAllText(path);
                    fi.Delete();

                    OneSecFFT2 = double.Parse(RData);
                    FTData2.Add(OneSecFFT2);
                }
            }
            avr1 = arr_avr(FTData2);
            userdata.Add(avr1);

            if ((double)userdata[0] > ct)
            {
                //영상
                // mainw.WindowState = WindowState.Minimized;
                keybd_event((byte)Keys.Q, 0, 0, 0);
                keybd_event((byte)Keys.Q, 0, 0x02, 0);
            }
            else //노래
            {
                Random rando = new Random();
                int ran = rando.Next(1, 3);
                Sound(ran);

                //mainw.WindowState = WindowState.Maximized;
                // mu.Stop();
                /* music.Open(new Uri(@"C:\Users\김나혜\Desktop\jujima.mp3"));
                 music.Play();
                 timer_c.Enabled = false;*/
                // Thread.Sleep(4500000);//몇분 후 종료
            }
            timer_c.Enabled = false;
        }


        //30초 마다 선택
        private static System.Windows.Forms.Timer timer_c2;
        public static void TicTok3()
        {
            timer_c2 = new System.Windows.Forms.Timer() { Interval = second3 * 1000 };
            timer_c2.Tick += new EventHandler(choice2);
            timer_c2.Enabled = true;
        }

        //30초마다 영상 or 노래
        public static double now_Data = 0.0;
        public static void choice2(object sender, System.EventArgs e)
        {
            while (FTData.Count < second3)
            {
                // int imsy = int.Parse(DateTime.Now.ToString("HH-mm-ss dd"));
                string path = @"C:\Users\김나혜\Desktop\bread data\" + count + ".txt";
                count++;

                FileInfo fi = new FileInfo(path);
                string RData = "0.1";
                if (fi.Exists == true)
                {
                    RData = System.IO.File.ReadAllText(path);
                    fi.Delete();

                    OneSecFFT3 = double.Parse(RData);
                    FTData3.Add(OneSecFFT3);
                }
            }
            avr1 = arr_avr(FTData3);
            userdata.Add(avr1);

            for (int i = 1; ; i++)
            {
                if (((double)userdata[i - 1] > ct) && ((double)userdata[i] > ct))
                {
                }
                else if (((double)userdata[i - 1] > ct) && ((double)userdata[i] <= ct))
                {
                    Random rando = new Random();
                    int ran = rando.Next(1, 3);
                    Sound(ran);
                    Thread.Sleep(233000);
                    timer_c2.Enabled = false;
                }
            }
        }

        //랜덤 노래 선택
        public static void Sound(int ran)
        {
            if (ran == 1)
            {
                keybd_event((byte)Keys.E, 0, 0, 0);
                keybd_event((byte)Keys.E, 0, 0x02, 0);
            }
            else if (ran == 2)
            {
                keybd_event((byte)Keys.R, 0, 0, 0);
                keybd_event((byte)Keys.R, 0, 0x02, 0);
            }
            else if (ran == 3)
            {
                keybd_event((byte)Keys.T, 0, 0, 0);
                keybd_event((byte)Keys.T, 0, 0x02, 0);
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            int time = 5000; // ms
            Thread.Sleep(time);
            //놔파 측정 시작
            keybd_event((byte)Keys.U, 0, 0, 0);
            keybd_event((byte)Keys.U, 0, 0x02, 0);        

            TicTok2();
            TicTok3();
        }
    }
}
